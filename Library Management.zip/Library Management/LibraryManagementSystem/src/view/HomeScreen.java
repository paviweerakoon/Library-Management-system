package view;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HomeScreen extends JFrame {
    public HomeScreen() {
        setTitle("Library Management System - Home");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JMenuBar menuBar = new JMenuBar();

        JMenu bookMenu = new JMenu("Books");
        JMenuItem manageBooksItem = new JMenuItem("Manage Books");
        manageBooksItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new BookManagementScreen().setVisible(true);
            }
        });
        bookMenu.add(manageBooksItem);
        menuBar.add(bookMenu);

        setJMenuBar(menuBar);
        
        JMenu memberMenu = new JMenu("Members");
        JMenuItem manageMembersItem = new JMenuItem("Manage Members");
        manageMembersItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new MemberManagementScreen().setVisible(true);
            }
        });
        memberMenu.add(manageMembersItem);
        menuBar.add(memberMenu);

        setJMenuBar(menuBar);
    }
}
