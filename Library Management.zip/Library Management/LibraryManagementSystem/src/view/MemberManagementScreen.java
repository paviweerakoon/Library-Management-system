package view;

import controller.MemberController;
import model.Member;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class MemberManagementScreen extends JFrame {

	private JTable table;
    private DefaultTableModel tableModel;
    private MemberController memberController;

    public MemberManagementScreen() {
        memberController = new MemberController();
        setTitle("Manage Members");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        tableModel = new DefaultTableModel(new String[]{"ID", "Name", "Email", "Phone", "Membership Date"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add Member");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addMember();
            }
        });
        buttonPanel.add(addButton);

        JButton updateButton = new JButton("Update Member");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateMember();
            }
        });
        buttonPanel.add(updateButton);

        JButton deleteButton = new JButton("Delete Member");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteMember();
            }
        });
        buttonPanel.add(deleteButton);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        add(panel);
        loadMembers();
    }

    private void loadMembers() {
        List<Member> members = memberController.getAllMembers();
        tableModel.setRowCount(0); // Clear existing data
        for (Member member : members) {
            tableModel.addRow(new Object[]{
                    member.getId(),
                    member.getName(),
                    member.getEmail(),
                    member.getPhone(),
                    member.getMembershipDate()
            });
        }
    }

    private void addMember() {
        String name = JOptionPane.showInputDialog("Enter member name:");
        String email = JOptionPane.showInputDialog("Enter member email:");
        String phone = JOptionPane.showInputDialog("Enter member phone:");
        String membershipDate = JOptionPane.showInputDialog("Enter membership date (YYYY-MM-DD):");

        Member member = new Member(0, name, email, phone, membershipDate);
        if (memberController.addMember(member)) {
            JOptionPane.showMessageDialog(null, "Member added successfully.");
            loadMembers();
        } else {
            JOptionPane.showMessageDialog(null, "Error adding member.");
        }
    }

    private void updateMember() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a member to update.");
            return;
        }

        int id = (int) tableModel.getValueAt(selectedRow, 0);
        String name = (String) tableModel.getValueAt(selectedRow, 1);
        String email = (String) tableModel.getValueAt(selectedRow, 2);
        String phone = (String) tableModel.getValueAt(selectedRow, 3);
        String membershipDate = (String) tableModel.getValueAt(selectedRow, 4);

        name = JOptionPane.showInputDialog("Enter member name:", name);
        email = JOptionPane.showInputDialog("Enter member email:", email);
        phone = JOptionPane.showInputDialog("Enter member phone:", phone);
        membershipDate = JOptionPane.showInputDialog("Enter membership date (YYYY-MM-DD):", membershipDate);

        Member member = new Member(id, name, email, phone, membershipDate);
        if (memberController.updateMember(member)) {
            JOptionPane.showMessageDialog(null, "Member updated successfully.");
            loadMembers();
        } else {
            JOptionPane.showMessageDialog(null, "Error updating member.");
        }
    }

    private void deleteMember() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a member to delete.");
            return;
        }

        int id = (int) tableModel.getValueAt(selectedRow, 0);
        if (memberController.deleteMember(id)) {
            JOptionPane.showMessageDialog(null, "Member deleted successfully.");
            loadMembers();
        } else {
            JOptionPane.showMessageDialog(null, "Error deleting member.");
        }
    }
}
