package view;

import controller.BookController;
import model.Book;


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class BookManagementScreen extends JFrame {

	private JTable table;
    private DefaultTableModel tableModel;
    private BookController bookController;
    
    public BookManagementScreen() {
        bookController = new BookController();
        setTitle("Manage Books");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        tableModel = new DefaultTableModel(new String[]{"ID", "Title", "Author", "Genre"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add Book");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addBook();
            }
        });
        buttonPanel.add(addButton);

        JButton updateButton = new JButton("Update Book");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateBook();
            }
        });
        buttonPanel.add(updateButton);

        JButton deleteButton = new JButton("Delete Book");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteBook();
            }
        });
        buttonPanel.add(deleteButton);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        add(panel);
        loadBooks();
    }
    
    private void loadBooks() {
        List<Book> books = bookController.getAllBooks();
        tableModel.setRowCount(0); // Clear existing data
        for (Book book : books) {
            tableModel.addRow(new Object[]{
                    book.getId(),
                    book.getTitle(),
                    book.getAuthor(),
                    book.getGenre(),
            });
        }
    }

    private void addBook() {
        String title = JOptionPane.showInputDialog("Enter book title:");
        String author = JOptionPane.showInputDialog("Enter book author:");
        String genre = JOptionPane.showInputDialog("Enter book genre:");

        Book book = new Book(0, title, author, genre);
        if (bookController.addBook(book)) {
            JOptionPane.showMessageDialog(null, "Book added successfully.");
            loadBooks();
        } else {
            JOptionPane.showMessageDialog(null, "Error adding book.");
        }
    }

    private void updateBook() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a book to update.");
            return;
        }

        int id = (int) tableModel.getValueAt(selectedRow, 0);
        String title = (String) tableModel.getValueAt(selectedRow, 1);
        String author = (String) tableModel.getValueAt(selectedRow, 2);
        String genre = (String) tableModel.getValueAt(selectedRow, 3);

        title = JOptionPane.showInputDialog("Enter book title:", title);
        author = JOptionPane.showInputDialog("Enter book author:", author);
        genre = JOptionPane.showInputDialog("Enter book genre:", genre);

        Book book = new Book(id, title, author, genre);
        if (bookController.updateBook(book)) {
            JOptionPane.showMessageDialog(null, "Book updated successfully.");
            loadBooks();
        } else {
            JOptionPane.showMessageDialog(null, "Error updating book.");
        }
    }

    private void deleteBook() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a book to delete.");
            return;
        }

        int id = (int) tableModel.getValueAt(selectedRow, 0);
        if (bookController.deleteBook(id)) {
            JOptionPane.showMessageDialog(null, "Book deleted successfully.");
            loadBooks();
        } else {
            JOptionPane.showMessageDialog(null, "Error deleting book.");
        }
    }
}
